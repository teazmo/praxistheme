          </div><!-- #content -->
        </main><!-- #main -->
<footer>
</footer><!-- #footer -->
</div><!-- #wrapper -->

<?php wp_footer(); ?>

</body>
</html>
