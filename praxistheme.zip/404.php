<?php get_header(); ?>
<div id="main">
<div id="content">
<h2>404 - Seite nicht gefunden</h2>
<p>Diese Seite existiert nicht</p>
<?php get_search_form(); ?>
</div><!-- #content -->

<div id="sidebar">
<?php get_sidebar(); ?>
</div><!-- #sidebar -->

<div class="clear"></div>
</div><!-- #main -->

<?php get_footer(); ?>
